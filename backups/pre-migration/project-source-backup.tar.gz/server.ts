import 'dotenv/config';
import express, { type NextFunction, type Request, type Response } from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {
  BLAUGRANA_DEFAULT_SIZE_PRICES,
  DEFAULT_STATUS_MESSAGES,
  buildOwnerOrderAlertMessage,
  buildVoucherCode,
  calculateCartSummary,
  compareProductsByCode,
  isPromoCodeValidNow,
  isQualifyingPerfumeCategory,
  normalizePhoneNumber,
  normalizePromoCode,
  resolveProductUnitPrice,
  sanitizeHref,
  sanitizeImageInput,
  validateCheckoutInput,
  validateCustomRequestInput,
  type AdminNotification,
  type AppliedPromoPreview,
  type CustomPerfumeRequest,
  type CustomRequestStatus,
  type Order,
  type OrderItem,
  type OrderStatus,
  type Product,
  type ProductCategory,
  type PromoCode,
  type PromoDiscountType,
  type SocialLink,
} from './src/utils/commerce.ts';
import {
  getOrCreateLoyaltyProfile,
  loadDatabase,
  saveDatabase,
  type DatabaseState,
} from './src/server/store.ts';

const PORT = Number(process.env.PORT) || 3000;

function getSessionSecret(db: DatabaseState): string {
  const envSecret = (process.env.SESSION_SECRET ?? '').trim();
  if (envSecret.length >= 16) {
    return envSecret;
  }
  if (db.sessionSecret && db.sessionSecret.length >= 16) {
    return db.sessionSecret;
  }
  const generated = crypto.randomBytes(32).toString('hex');
  db.sessionSecret = generated;
  saveDatabase(db);
  return generated;
}

const VALID_CATEGORIES = new Set<ProductCategory>([
  'blaugrana',
  'other_brands',
  'body_mist',
  'room_spray',
  'deodorant',
  'hair_care',
  'tester',
]);

const VALID_ORDER_STATUSES = new Set<OrderStatus>([
  'تم الاستلام',
  'قيد المراجعة',
  'تم التجهيز',
  'قيد التوصيل',
  'تم التسليم',
]);

const VALID_REQUEST_STATUSES = new Set<CustomRequestStatus>([
  'قيد البحث',
  'تم التوفير',
  'تم التواصل',
]);

const DEFAULT_IMAGES: Record<ProductCategory, string> = {
  blaugrana: '/src/assets/images/perfume_signature_oud_1795208161900.jpg',
  other_brands: '/src/assets/images/perfume_crimson_rose_1795208162606.jpg',
  body_mist: '/src/assets/images/product_body_mist_1795208162237.jpg',
  room_spray: '/src/assets/images/product_body_mist_1795208162237.jpg',
  deodorant: '/src/assets/images/product_body_mist_1795208162237.jpg',
  hair_care: '/assets/aistudio/hair_shampoo_studio.jpg',
  tester: '/src/assets/images/product_tester_kit_1795208162880.jpg',
};

function getEnvAdminPasscode(): string {
  return (process.env.ADMIN_PASSCODE ?? '').trim();
}

function getAdminAuthMode(db: ReturnType<typeof loadDatabase>) {
  if (getEnvAdminPasscode().length > 0) {
    return { configured: true, mode: 'env' as const };
  }
  if (db.adminCredential) {
    return { configured: true, mode: 'claimed' as const };
  }
  return { configured: false, mode: 'unclaimed' as const };
}

function verifyPasscodeConstantTime(candidate: string, expected: string): boolean {
  const a = crypto.createHash('sha256').update(candidate).digest();
  const b = crypto.createHash('sha256').update(expected).digest();
  return crypto.timingSafeEqual(a, b);
}

function hashPasscodeScrypt(passcode: string, saltHex: string): string {
  return crypto.scryptSync(passcode, saltHex, 64).toString('hex');
}

function signAdminToken(db: DatabaseState): string {
  const payload = {
    role: 'admin',
    iat: Date.now(),
    exp: Date.now() + 7 * 24 * 60 * 60 * 1000,
    jti: crypto.randomUUID(),
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString(
    'base64url'
  );
  const sig = crypto
    .createHmac('sha256', getSessionSecret(db))
    .update(encoded)
    .digest('base64url');
  return `${encoded}.${sig}`;
}

function verifyAdminToken(token: string, db: DatabaseState): boolean {
  const parts = token.split('.');
  if (parts.length !== 2) return false;
  const [encoded, sig] = parts;
  if (!encoded || !sig) return false;

  const expectedSig = crypto
    .createHmac('sha256', getSessionSecret(db))
    .update(encoded)
    .digest('base64url');

  const sigBuf = Buffer.from(sig, 'utf8');
  const expectedBuf = Buffer.from(expectedSig, 'utf8');
  if (sigBuf.length !== expectedBuf.length) return false;
  if (!crypto.timingSafeEqual(sigBuf, expectedBuf)) return false;

  try {
    const parsed = JSON.parse(
      Buffer.from(encoded, 'base64url').toString('utf8')
    ) as { role?: string; exp?: number };
    if (parsed.role !== 'admin') return false;
    if (typeof parsed.exp !== 'number' || parsed.exp < Date.now()) return false;
    return true;
  } catch {
    return false;
  }
}

function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization ?? '';
  if (!authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'يرجى تسجيل الدخول للإدارة أولاً.' });
    return;
  }
  const token = authHeader.slice(7).trim();
  const db = loadDatabase();
  if (!verifyAdminToken(token, db)) {
    res.status(401).json({ error: 'انتهت صلاحية الجلسة، يرجى إعادة الدخول.' });
    return;
  }
  next();
}

const UPLOADS_DIR = path.resolve(process.cwd(), 'public', 'uploads');

function hasValidImageMagicBytes(buf: Buffer, ext: string): boolean {
  if (buf.length < 12) return false;
  if (ext === 'jpg') {
    return buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  }
  if (ext === 'png') {
    return (
      buf[0] === 0x89 &&
      buf[1] === 0x50 &&
      buf[2] === 0x4e &&
      buf[3] === 0x47
    );
  }
  if (ext === 'webp') {
    return (
      buf.subarray(0, 4).toString('ascii') === 'RIFF' &&
      buf.subarray(8, 12).toString('ascii') === 'WEBP'
    );
  }
  return false;
}

function sanitizeImageUrl(url: unknown, fallbackCategory: ProductCategory): string {
  return sanitizeImageInput(url, DEFAULT_IMAGES[fallbackCategory]);
}

function buildCombinedNotes(
  rawNotes: string,
  topNotes?: string,
  heartNotes?: string,
  baseNotes?: string
): string {
  const structured = [topNotes, heartNotes, baseNotes]
    .map((s) => (s ?? '').trim())
    .filter(Boolean);
  if (structured.length > 0) {
    return structured.join(' · ');
  }
  return rawNotes.trim() || 'تركيبة فاخرة مختارة بعناية';
}

const app = express();
app.use(express.json({ limit: '10mb' }));
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
app.use('/uploads', express.static(UPLOADS_DIR));

const adminStreamClients = new Set<Response>();

function broadcastAdminEvent(eventName: string, payload: unknown): void {
  const frame = `event: ${eventName}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const client of adminStreamClients) {
    try {
      client.write(frame);
    } catch {
      adminStreamClients.delete(client);
    }
  }
}

function getEffectiveTelegramCredentials(db: DatabaseState): {
  botToken: string;
  chatId: string;
} | null {
  const envToken = (process.env.TELEGRAM_BOT_TOKEN ?? '').trim();
  const envChat = (process.env.TELEGRAM_CHAT_ID ?? '').trim();
  if (envToken && envChat) {
    return { botToken: envToken, chatId: envChat };
  }
  if (db.telegramConfig?.botToken && db.telegramConfig?.chatId) {
    return {
      botToken: db.telegramConfig.botToken,
      chatId: db.telegramConfig.chatId,
    };
  }
  return null;
}

function getTelegramPublicStatus(db: DatabaseState) {
  const creds = getEffectiveTelegramCredentials(db);
  if (!creds) {
    return { configured: false, chatIdMasked: '' };
  }
  const cid = creds.chatId;
  const masked =
    cid.length > 4 ? `${'*'.repeat(Math.max(2, cid.length - 4))}${cid.slice(-4)}` : '****';
  return { configured: true, chatIdMasked: masked };
}

async function sendTelegramOwnerAlert(
  db: DatabaseState,
  text: string
): Promise<{ sent: boolean; error?: string }> {
  const creds = getEffectiveTelegramCredentials(db);
  if (!creds) return { sent: false };
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 4000);
  try {
    const resp = await fetch(
      `https://api.telegram.org/bot${creds.botToken}/sendMessage`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: creds.chatId,
          text,
        }),
        signal: controller.signal,
      }
    );
    if (!resp.ok) {
      const errBody = await resp.text().catch(() => '');
      console.error(`Telegram alert HTTP ${resp.status}:`, errBody);
      return { sent: false, error: `HTTP ${resp.status}` };
    }
    return { sent: true };
  } catch (err) {
    console.error('Telegram alert failed:', err);
    return { sent: false, error: 'Network error' };
  } finally {
    clearTimeout(timeoutId);
  }
}

// Public Storefront Bootstrap
app.get('/api/bootstrap', (_req, res) => {
  const db = loadDatabase();
  res.json({
    storeInfo: db.storeInfo,
    products: db.products,
    socialLinks: db.socialLinks,
    adminAuthState: getAdminAuthMode(db),
  });
});

// Loyalty Stamp Lookup by Phone
app.get('/api/loyalty/:phone', (req, res) => {
  const normalized = normalizePhoneNumber(String(req.params.phone ?? ''));
  if (normalized.length < 10) {
    res.status(400).json({ error: 'يرجى إدخال رقم هاتف صحيح.' });
    return;
  }
  const db = loadDatabase();
  const profile = getOrCreateLoyaltyProfile(db, normalized);
  res.json({ loyalty: profile });
});

// Public Customer Order Tracking (requires matching orderNumber + phone)
app.get('/api/orders/track', (req, res) => {
  const orderNumberRaw =
    typeof req.query.orderNumber === 'string'
      ? req.query.orderNumber.trim().toUpperCase()
      : '';
  const phoneRaw =
    typeof req.query.phone === 'string' ? req.query.phone.trim() : '';
  const normalizedPhone = normalizePhoneNumber(phoneRaw);

  if (!orderNumberRaw || normalizedPhone.length < 10) {
    res.status(400).json({
      error: 'يرجى إدخال رقم الطلب (مثال: BG-1001) ورقم الهاتف المستخدم عند الطلب.',
    });
    return;
  }

  const db = loadDatabase();
  const found = db.orders.find(
    (o) =>
      o.orderNumber.toUpperCase() === orderNumberRaw &&
      normalizePhoneNumber(o.phone) === normalizedPhone
  );

  if (!found) {
    res.status(404).json({
      error: 'لم نعثر على طلب مطابق لرقم الطلب ورقم الهاتف المدخلين.',
    });
    return;
  }

  res.json({
    order: {
      id: found.id,
      orderNumber: found.orderNumber,
      createdAt: found.createdAt,
      deliveredAt: found.deliveredAt,
      fullName: found.fullName,
      exactLocation: found.exactLocation,
      phone: found.phone,
      items: found.items,
      pricing: found.pricing,
      voucherCode: found.voucherCode,
      status: found.status,
      estimatedArrival: found.estimatedArrival,
      statusMessage: found.statusMessage,
      statusHistory: found.statusHistory,
    },
  });
});

// Public Promo Code Validation
app.post('/api/promo-codes/validate', (req, res) => {
  const rawCode = typeof req.body?.code === 'string' ? req.body.code : '';
  const code = normalizePromoCode(rawCode);
  if (!code) {
    res.status(400).json({ error: 'يرجى إدخال كود الخصم أولاً.' });
    return;
  }
  const db = loadDatabase();
  const found = db.promoCodes.find((p) => normalizePromoCode(p.code) === code);
  if (!found) {
    res.status(404).json({
      error: 'كود الخصم غير موجود أو غير مفعّل حالياً.',
    });
    return;
  }
  const validity = isPromoCodeValidNow(found);
  if (validity.expired) {
    res.status(410).json({
      error: 'انتهت صلاحية كود الخصم هذا.',
    });
    return;
  }
  if (!found.active) {
    res.status(404).json({
      error: 'كود الخصم متوقف حالياً.',
    });
    return;
  }
  const promo: AppliedPromoPreview = {
    code: found.code,
    ownerName: found.ownerName,
    discountType: found.discountType,
    discountValue: found.discountValue,
    expiresAt: found.expiresAt ?? null,
  };
  res.json({ promo });
});

// Create Order (Checkout)
app.post('/api/orders', async (req, res) => {
  const body = req.body as {
    fullName?: unknown;
    exactLocation?: unknown;
    birthDate?: unknown;
    phone?: unknown;
    promoCode?: unknown;
    items?: Array<{
      productId?: unknown;
      selectedSize?: unknown;
      quantity?: unknown;
    }>;
  };

  const fullName = typeof body.fullName === 'string' ? body.fullName.trim() : '';
  const exactLocation =
    typeof body.exactLocation === 'string' ? body.exactLocation.trim() : '';
  const birthDate =
    typeof body.birthDate === 'string' ? body.birthDate.trim() : '';
  const phoneRaw = typeof body.phone === 'string' ? body.phone.trim() : '';
  const rawPromoCode =
    typeof body.promoCode === 'string' ? normalizePromoCode(body.promoCode) : '';
  const rawItems = Array.isArray(body.items) ? body.items : [];

  const db = loadDatabase();
  const resolvedCart: Array<{
    product: Product;
    selectedSize: string;
    unitPriceIqd: number;
    quantity: number;
  }> = [];

  for (const entry of rawItems) {
    const productId =
      typeof entry?.productId === 'string' ? entry.productId.trim() : '';
    const requestedSize =
      typeof entry?.selectedSize === 'string' ? entry.selectedSize.trim() : undefined;
    const quantity = Math.floor(Number(entry?.quantity ?? 0));
    if (!productId || !Number.isFinite(quantity) || quantity <= 0 || quantity > 50) {
      continue;
    }
    const found = db.products.find((p) => p.id === productId);
    if (found && found.inStock) {
      const resolved = resolveProductUnitPrice(found, requestedSize);
      resolvedCart.push({
        product: found,
        selectedSize: resolved.size,
        unitPriceIqd: resolved.priceIqd,
        quantity,
      });
    }
  }

  const validation = validateCheckoutInput({
    fullName,
    exactLocation,
    birthDate,
    phone: phoneRaw,
    itemsCount: resolvedCart.length,
  });

  if (!validation.valid) {
    res.status(400).json({ error: Object.values(validation.errors)[0], errors: validation.errors });
    return;
  }

  let matchedPromoRecord: PromoCode | undefined;
  let appliedPromo: AppliedPromoPreview | null = null;
  if (rawPromoCode) {
    matchedPromoRecord = db.promoCodes.find(
      (p) => normalizePromoCode(p.code) === rawPromoCode
    );
    if (!matchedPromoRecord) {
      res.status(400).json({
        error: 'كود الخصم المدخل غير صحيح أو غير مفعّل.',
      });
      return;
    }
    const promoValidity = isPromoCodeValidNow(matchedPromoRecord);
    if (promoValidity.expired) {
      res.status(410).json({
        error: 'انتهت صلاحية كود الخصم هذا.',
      });
      return;
    }
    if (!matchedPromoRecord.active) {
      res.status(400).json({
        error: 'كود الخصم متوقف حالياً.',
      });
      return;
    }
    appliedPromo = {
      code: matchedPromoRecord.code,
      ownerName: matchedPromoRecord.ownerName,
      discountType: matchedPromoRecord.discountType,
      discountValue: matchedPromoRecord.discountValue,
      expiresAt: matchedPromoRecord.expiresAt ?? null,
    };
  }

  const normalizedPhone = normalizePhoneNumber(phoneRaw);
  const priorProfile = getOrCreateLoyaltyProfile(db, normalizedPhone);
  const pricing = calculateCartSummary(
    resolvedCart.map((c) => ({
      product: c.product,
      selectedSize: c.selectedSize,
      quantity: c.quantity,
    })),
    priorProfile.totalQualifyingPerfumes,
    appliedPromo
  );

  const orderNumber = `BG-${db.orderSequence}`;
  db.orderSequence += 1;

  const orderItems: OrderItem[] = resolvedCart.map(
    ({ product, selectedSize, unitPriceIqd, quantity }) => ({
      productId: product.id,
      code: product.code,
      name: product.name,
      brand: product.brand,
      category: product.category,
      size: selectedSize,
      priceIqd: unitPriceIqd,
      quantity,
      includesFreeTester:
        product.includesFreeTester || isQualifyingPerfumeCategory(product.category),
    })
  );

  const voucherCode = buildVoucherCode(normalizedPhone);
  const nowIso = new Date().toISOString();
  const newOrder: Order = {
    id: crypto.randomUUID(),
    orderNumber,
    createdAt: nowIso,
    fullName,
    exactLocation,
    birthDate,
    phone: normalizedPhone,
    items: orderItems,
    pricing,
    voucherCode,
    status: 'تم الاستلام',
    estimatedArrival: 'خلال 24 إلى 48 ساعة',
    statusMessage: DEFAULT_STATUS_MESSAGES['تم الاستلام'],
    statusHistory: [
      {
        status: 'تم الاستلام',
        timestamp: nowIso,
        note: 'تم تأكيد استلام الطلب بنجاح وجاري تحويله للتجهيز.',
      },
    ],
  };

  const newTotalPerfumes =
    priorProfile.totalQualifyingPerfumes + pricing.qualifyingPerfumeUnits;
  const updatedLoyalty = {
    phone: normalizedPhone,
    totalQualifyingPerfumes: newTotalPerfumes,
    stamps: newTotalPerfumes % 5,
    stampsRemainingForFree: 5 - (newTotalPerfumes % 5),
    freePerfumesRedeemed:
      priorProfile.freePerfumesRedeemed + pricing.freePerfumeUnitsEarned,
    voucherCode,
    ordersCount: priorProfile.ordersCount + 1,
  };

  if (matchedPromoRecord && pricing.promoDiscountIqd > 0) {
    matchedPromoRecord.timesUsed = (matchedPromoRecord.timesUsed ?? 0) + 1;
  }

  const ownerAlertText = buildOwnerOrderAlertMessage(newOrder);
  const itemsSummary = orderItems
    .map((it) => `#${it.code} ${it.name}${it.size ? ` (${it.size})` : ''} × ${it.quantity}`)
    .join('، ');

  const notification: AdminNotification = {
    id: crypto.randomUUID(),
    createdAt: nowIso,
    type: 'new_order',
    orderId: newOrder.id,
    orderNumber: newOrder.orderNumber,
    customerName: fullName,
    customerPhone: normalizedPhone,
    exactLocation,
    totalIqd: pricing.totalIqd,
    itemsSummary,
    message: ownerAlertText,
    read: false,
  };

  db.loyaltyByPhone[normalizedPhone] = updatedLoyalty;
  db.orders.unshift(newOrder);
  db.notifications.unshift(notification);
  saveDatabase(db);

  broadcastAdminEvent('new_order', {
    order: newOrder,
    notification,
  });
  await sendTelegramOwnerAlert(db, ownerAlertText);

  res.status(201).json({
    order: newOrder,
    loyalty: updatedLoyalty,
    thankYouMessage: `شكراً لك من القلب يا ${fullName} على ثقتك بوكالة بلوكرانا للعطور! تم استلام طلبك رقم ${orderNumber} بنجاح، وسيتم تجهيز عطرك مع تيستر التجربة المجاني وضمان الثبات والفوحان الذهبي.`,
  });
});

// Create "وفرلي عطري" Custom Perfume Request
app.post('/api/custom-requests', async (req, res) => {
  const body = req.body as {
    perfumeName?: unknown;
    expectedPriceIqd?: unknown;
    size?: unknown;
    desiredDate?: unknown;
    customerName?: unknown;
    customerPhone?: unknown;
    notes?: unknown;
  };

  const perfumeName =
    typeof body.perfumeName === 'string' ? body.perfumeName.trim() : '';
  const expectedPriceIqd = Number(body.expectedPriceIqd ?? 0);
  const size = typeof body.size === 'string' ? body.size.trim() : '';
  const desiredDate =
    typeof body.desiredDate === 'string' ? body.desiredDate.trim() : '';
  const customerName =
    typeof body.customerName === 'string' ? body.customerName.trim() : '';
  const customerPhone =
    typeof body.customerPhone === 'string' ? body.customerPhone.trim() : '';
  const notes = typeof body.notes === 'string' ? body.notes.trim() : '';

  const validation = validateCustomRequestInput({
    perfumeName,
    expectedPriceIqd,
    size,
    desiredDate,
    customerName,
    customerPhone,
  });

  if (!validation.valid) {
    res.status(400).json({ error: Object.values(validation.errors)[0], errors: validation.errors });
    return;
  }

  const db = loadDatabase();
  const nowIso = new Date().toISOString();
  const normalizedPhone = normalizePhoneNumber(customerPhone);
  const created: CustomPerfumeRequest = {
    id: crypto.randomUUID(),
    createdAt: nowIso,
    perfumeName,
    expectedPriceIqd: Math.round(expectedPriceIqd),
    size,
    desiredDate,
    customerName,
    customerPhone: normalizedPhone,
    notes,
    status: 'قيد البحث',
  };

  const alertText = [
    `✨ طلب «وفرلي عطري» جديد`,
    `🧴 العطر: ${perfumeName} (${size})`,
    `👤 الزبون: ${customerName}`,
    `📱 الهاتف: ${normalizedPhone}`,
    `💰 السعر المتوقع: ${expectedPriceIqd.toLocaleString('en-US')} د.ع`,
    `📅 التاريخ المطلوب: ${desiredDate}`,
  ].join('\n');

  const notification: AdminNotification = {
    id: crypto.randomUUID(),
    createdAt: nowIso,
    type: 'custom_request',
    customerName,
    customerPhone: normalizedPhone,
    itemsSummary: `وفرلي عطري: ${perfumeName} (${size})`,
    message: alertText,
    read: false,
  };

  db.customRequests.unshift(created);
  db.notifications.unshift(notification);
  saveDatabase(db);

  broadcastAdminEvent('custom_request', {
    request: created,
    notification,
  });
  await sendTelegramOwnerAlert(db, alertText);

  res.status(201).json({
    request: created,
    message: `تم تسجيل طلب "وفرلي عطري" بنجاح! سيعمل فريق بلوكرانا على توفير عطر "${perfumeName}" والتواصل معك قبل ${desiredDate}.`,
  });
});

// Admin First-Run Claim (only when ADMIN_PASSCODE env is unset and no hash saved)
app.post('/api/admin/claim', (req, res) => {
  const db = loadDatabase();
  const mode = getAdminAuthMode(db);
  if (mode.configured) {
    res.status(409).json({
      error: 'رمز الإدارة مُعد مسبقاً. يرجى تسجيل الدخول مباشرة.',
    });
    return;
  }
  const passcode =
    typeof req.body?.passcode === 'string' ? req.body.passcode.trim() : '';
  if (passcode.length < 4 || passcode.length > 64) {
    res.status(400).json({
      error: 'يجب أن يتكون رمز الإدارة من 4 أحرف أو أرقام على الأقل.',
    });
    return;
  }

  const saltHex = crypto.randomBytes(16).toString('hex');
  const hashHex = hashPasscodeScrypt(passcode, saltHex);
  db.adminCredential = {
    saltHex,
    hashHex,
    claimedAt: new Date().toISOString(),
  };
  saveDatabase(db);

  const token = signAdminToken(db);
  res.status(201).json({
    token,
    adminAuthState: getAdminAuthMode(db),
  });
});

// Admin Login
app.post('/api/admin/login', (req, res) => {
  const passcode =
    typeof req.body?.passcode === 'string' ? req.body.passcode.trim() : '';
  if (!passcode) {
    res.status(400).json({ error: 'يرجى إدخال رمز الإدارة.' });
    return;
  }

  const db = loadDatabase();
  const envPasscode = getEnvAdminPasscode();

  if (envPasscode.length > 0) {
    if (!verifyPasscodeConstantTime(passcode, envPasscode)) {
      res.status(401).json({ error: 'رمز الإدارة غير صحيح.' });
      return;
    }
    res.json({ token: signAdminToken(db), adminAuthState: getAdminAuthMode(db) });
    return;
  }

  if (!db.adminCredential) {
    res.status(403).json({
      error: 'لم يتم تفعيل رمز الإدارة بعد. يرجى إعداده أولاً.',
    });
    return;
  }

  const candidateHashHex = hashPasscodeScrypt(
    passcode,
    db.adminCredential.saltHex
  );
  const a = Buffer.from(candidateHashHex, 'hex');
  const b = Buffer.from(db.adminCredential.hashHex, 'hex');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    res.status(401).json({ error: 'رمز الإدارة غير صحيح.' });
    return;
  }

  res.json({ token: signAdminToken(db), adminAuthState: getAdminAuthMode(db) });
});

// Admin Dashboard Data
app.get('/api/admin/dashboard', requireAdmin, (_req, res) => {
  const db = loadDatabase();
  res.json({
    orders: db.orders,
    customRequests: db.customRequests,
    notifications: db.notifications,
    products: db.products,
    socialLinks: db.socialLinks,
    promoCodes: db.promoCodes,
    loyaltyCount: Object.keys(db.loyaltyByPhone).length,
    telegramStatus: getTelegramPublicStatus(db),
  });
});

// Admin Real-Time Notification Stream (SSE over Bearer auth)
app.get('/api/admin/notifications/stream', requireAdmin, (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  adminStreamClients.add(res);
  res.write(`event: connected\ndata: ${JSON.stringify({ ok: true })}\n\n`);

  const keepAlive = setInterval(() => {
    try {
      res.write(': ping\n\n');
    } catch {
      clearInterval(keepAlive);
      adminStreamClients.delete(res);
    }
  }, 25000);

  req.on('close', () => {
    clearInterval(keepAlive);
    adminStreamClients.delete(res);
  });
});

// Mark Admin Notifications Read
app.patch('/api/admin/notifications/read-all', requireAdmin, (_req, res) => {
  const db = loadDatabase();
  db.notifications = db.notifications.map((n) => ({ ...n, read: true }));
  saveDatabase(db);
  res.json({ ok: true, notifications: db.notifications });
});

// Configure Owner Telegram Instant Alert Bot (Stored securely on server)
app.put('/api/admin/telegram-config', requireAdmin, (req, res) => {
  const botToken =
    typeof req.body?.botToken === 'string' ? req.body.botToken.trim() : '';
  const chatId =
    typeof req.body?.chatId === 'string' ? req.body.chatId.trim() : '';

  if (
    !/^\d{5,}:[A-Za-z0-9_-]{20,}$/.test(botToken) ||
    !/^(-?\d{5,}|@[A-Za-z0-9_]{4,})$/.test(chatId)
  ) {
    res.status(400).json({
      error:
        'يرجى إدخال Bot Token صحيح (من @BotFather) و Chat ID صحيح لإرسال الإشعارات.',
    });
    return;
  }

  const db = loadDatabase();
  db.telegramConfig = {
    botToken,
    chatId,
    updatedAt: new Date().toISOString(),
  };
  saveDatabase(db);
  res.json({ telegramStatus: getTelegramPublicStatus(db) });
});

app.delete('/api/admin/telegram-config', requireAdmin, (_req, res) => {
  const db = loadDatabase();
  db.telegramConfig = null;
  saveDatabase(db);
  res.json({ telegramStatus: getTelegramPublicStatus(db) });
});

app.post('/api/admin/telegram-test', requireAdmin, async (_req, res) => {
  const db = loadDatabase();
  const result = await sendTelegramOwnerAlert(
    db,
    '🔔 رسالة اختبار من لوحة تحكم وكالة بلوكرانا للعطور — الإشعارات الفورية مفعلة وتعمل بنجاح!'
  );
  if (!result.sent) {
    res.status(400).json({
      error: result.error
        ? `تعذر إرسال رسالة الاختبار (${result.error}). تأكد من تفعيل البوت وإرسال /start له أولاً.`
        : 'لم يتم ربط بوت تيليغرام بعد.',
    });
    return;
  }
  res.json({ ok: true });
});

// Admin Update Order Status, Estimated Arrival Time, and Customer Note
app.patch('/api/admin/orders/:id', requireAdmin, (req, res) => {
  const body = req.body as {
    status?: unknown;
    estimatedArrival?: unknown;
    statusMessage?: unknown;
  };
  const status = body.status as OrderStatus;
  if (!VALID_ORDER_STATUSES.has(status)) {
    res.status(400).json({ error: 'حالة الطلب غير صالحة.' });
    return;
  }
  const db = loadDatabase();
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) {
    res.status(404).json({ error: 'الطلب غير موجود.' });
    return;
  }

  const nowIso = new Date().toISOString();
  const prevStatus = order.status;
  order.status = status;

  if (typeof body.estimatedArrival === 'string' && body.estimatedArrival.trim()) {
    order.estimatedArrival = body.estimatedArrival.trim();
  }
  if (typeof body.statusMessage === 'string' && body.statusMessage.trim()) {
    order.statusMessage = body.statusMessage.trim();
  } else if (prevStatus !== status) {
    order.statusMessage = DEFAULT_STATUS_MESSAGES[status];
  }

  if (status === 'تم التسليم' && !order.deliveredAt) {
    order.deliveredAt = nowIso;
  }

  if (!Array.isArray(order.statusHistory)) {
    order.statusHistory = [{ status: prevStatus, timestamp: order.createdAt }];
  }
  if (
    prevStatus !== status ||
    (typeof body.statusMessage === 'string' && body.statusMessage.trim())
  ) {
    order.statusHistory.push({
      status,
      timestamp: nowIso,
      note: order.statusMessage,
    });
  }

  saveDatabase(db);
  res.json({ order });
});

// Admin Update Custom Request Status
app.patch('/api/admin/custom-requests/:id', requireAdmin, (req, res) => {
  const status = req.body?.status as CustomRequestStatus;
  if (!VALID_REQUEST_STATUSES.has(status)) {
    res.status(400).json({ error: 'حالة الطلب الخاص غير صالحة.' });
    return;
  }
  const db = loadDatabase();
  const customReq = db.customRequests.find((r) => r.id === req.params.id);
  if (!customReq) {
    res.status(404).json({ error: 'الطلب الخاص غير موجود.' });
    return;
  }
  customReq.status = status;
  saveDatabase(db);
  res.json({ request: customReq });
});

// Admin Upload Product Image (JPEG / PNG / WebP up to 5MB)
app.post('/api/admin/upload-image', requireAdmin, (req, res) => {
  const dataUrl =
    typeof req.body?.dataUrl === 'string' ? req.body.dataUrl.trim() : '';
  const match = dataUrl.match(
    /^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=]+)$/i
  );
  if (!match) {
    res.status(400).json({
      error: 'صيغة الصورة غير مدعومة. يرجى اختيار صورة JPG أو PNG أو WEBP.',
    });
    return;
  }

  const rawSubtype = match[1].toLowerCase();
  const ext = rawSubtype === 'jpeg' || rawSubtype === 'jpg' ? 'jpg' : rawSubtype;
  const buf = Buffer.from(match[2], 'base64');

  if (buf.length === 0 || buf.length > 5 * 1024 * 1024) {
    res.status(400).json({
      error: 'حجم الصورة يجب أن يكون أقل من 5 ميغابايت.',
    });
    return;
  }

  if (!hasValidImageMagicBytes(buf, ext)) {
    res.status(400).json({
      error: 'تعذر التحقق من محتوى الصورة المرفوعة.',
    });
    return;
  }

  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
  const filename = `${crypto.randomUUID()}.${ext}`;
  const targetPath = path.resolve(UPLOADS_DIR, filename);
  if (!targetPath.startsWith(UPLOADS_DIR + path.sep)) {
    res.status(400).json({ error: 'مسار غير صالح لحفظ الصورة.' });
    return;
  }

  fs.writeFileSync(targetPath, buf);
  res.status(201).json({ imageUrl: `/uploads/${filename}` });
});

// Admin Bulk Update Product Prices (All Perfumes or Specific Category / Blaugrana Size Tiers)
app.patch('/api/admin/products/bulk-prices', requireAdmin, (req, res) => {
  const body = req.body as {
    mode?: unknown;
    price30?: unknown;
    price50?: unknown;
    price100?: unknown;
    category?: unknown;
    adjustType?: unknown;
    value?: unknown;
  };

  const db = loadDatabase();
  let updatedCount = 0;

  if (body.mode === 'blaugrana_sizes') {
    const p30 = Math.round(Number(body.price30 ?? 0));
    const p50 = Math.round(Number(body.price50 ?? 0));
    const p100 = Math.round(Number(body.price100 ?? 0));
    if (
      !Number.isFinite(p30) ||
      p30 < 500 ||
      !Number.isFinite(p50) ||
      p50 < 500 ||
      !Number.isFinite(p100) ||
      p100 < 500
    ) {
      res.status(400).json({
        error: 'يرجى إدخال أسعار صحيحة (500 د.ع فأكثر) لأحجام 30 مل و50 مل و100 مل.',
      });
      return;
    }

    db.products = db.products.map((product) => {
      if (product.category !== 'blaugrana') return product;
      updatedCount += 1;
      return {
        ...product,
        size: '100 مل',
        priceIqd: p100,
        sizePrices: {
          '30 مل': p30,
          '50 مل': p50,
          '100 مل': p100,
        },
      };
    });
    saveDatabase(db);
    res.json({ updatedCount, products: db.products });
    return;
  }

  if (body.mode === 'category_adjust') {
    const categoryRaw = typeof body.category === 'string' ? body.category : 'all';
    const adjustType = body.adjustType as 'percent' | 'fixed_price' | 'fixed_delta';
    const value = Number(body.value ?? 0);
    if (!Number.isFinite(value)) {
      res.status(400).json({ error: 'قيمة التعديل غير صالحة.' });
      return;
    }
    if (adjustType === 'fixed_price' && value < 500) {
      res.status(400).json({ error: 'السعر الموحد يجب أن لا يقل عن 500 د.ع.' });
      return;
    }
    if (adjustType === 'percent' && (value <= -95 || value > 500)) {
      res.status(400).json({ error: 'النسبة المئوية يجب أن تكون بين -95% و 500%.' });
      return;
    }

    const applyAdjustment = (oldPrice: number): number => {
      if (adjustType === 'fixed_price') {
        return Math.max(500, Math.round(value));
      }
      if (adjustType === 'percent') {
        return Math.max(500, Math.round((oldPrice * (100 + value)) / 100));
      }
      return Math.max(500, Math.round(oldPrice + value));
    };

    db.products = db.products.map((product) => {
      if (categoryRaw !== 'all' && product.category !== categoryRaw) {
        return product;
      }
      updatedCount += 1;
      const nextPrice = applyAdjustment(product.priceIqd);
      let nextSizePrices = product.sizePrices;
      if (product.sizePrices) {
        const updatedSizes: Record<string, number> = {};
        for (const [sz, oldSzPrice] of Object.entries(product.sizePrices)) {
          updatedSizes[sz] = applyAdjustment(oldSzPrice);
        }
        nextSizePrices = updatedSizes;
      }
      return {
        ...product,
        priceIqd:
          nextSizePrices && typeof nextSizePrices['100 مل'] === 'number'
            ? nextSizePrices['100 مل']
            : nextPrice,
        ...(nextSizePrices ? { sizePrices: nextSizePrices } : {}),
      };
    });

    saveDatabase(db);
    res.json({ updatedCount, products: db.products });
    return;
  }

  res.status(400).json({ error: 'نوع تعديل الأسعار غير مدعوم.' });
});

// Admin Add Product (Single or Bulk)
app.post('/api/admin/products', requireAdmin, (req, res) => {
  const itemsInput = Array.isArray(req.body?.items)
    ? req.body.items
    : [req.body];

  const db = loadDatabase();
  const createdProducts: Product[] = [];

  for (const item of itemsInput) {
    const code = typeof item?.code === 'string' ? item.code.trim() : '';
    const name = typeof item?.name === 'string' ? item.name.trim() : '';
    const brand =
      typeof item?.brand === 'string' && item.brand.trim()
        ? item.brand.trim()
        : 'بلوكرانا';
    const categoryRaw = item?.category as ProductCategory;
    const category: ProductCategory = VALID_CATEGORIES.has(categoryRaw)
      ? categoryRaw
      : 'blaugrana';
    let priceIqd = Math.round(Number(item?.priceIqd ?? 0));
    const size =
      typeof item?.size === 'string' && item.size.trim()
        ? item.size.trim()
        : '100 مل';

    let sizePrices: Record<string, number> | undefined;
    if (item?.sizePrices && typeof item.sizePrices === 'object') {
      const cleaned: Record<string, number> = {};
      for (const [sz, pr] of Object.entries(
        item.sizePrices as Record<string, unknown>
      )) {
        const num = Math.round(Number(pr));
        if (sz.trim() && Number.isFinite(num) && num >= 500) {
          cleaned[sz.trim()] = num;
        }
      }
      if (Object.keys(cleaned).length > 0) {
        sizePrices = cleaned;
        if (typeof cleaned['100 مل'] === 'number') {
          priceIqd = cleaned['100 مل'];
        }
      }
    } else if (category === 'blaugrana') {
      sizePrices = {
        ...BLAUGRANA_DEFAULT_SIZE_PRICES,
        ...(priceIqd >= 500 ? { '100 مل': priceIqd } : {}),
      };
      if (priceIqd <= 0) {
        priceIqd = BLAUGRANA_DEFAULT_SIZE_PRICES['100 مل'];
      }
    }

    const topNotes =
      typeof item?.topNotes === 'string' && item.topNotes.trim()
        ? item.topNotes.trim()
        : undefined;
    const heartNotes =
      typeof item?.heartNotes === 'string' && item.heartNotes.trim()
        ? item.heartNotes.trim()
        : undefined;
    const baseNotes =
      typeof item?.baseNotes === 'string' && item.baseNotes.trim()
        ? item.baseNotes.trim()
        : undefined;
    const rawNotes = typeof item?.notes === 'string' ? item.notes.trim() : '';
    const notes = rawNotes
      ? rawNotes
      : buildCombinedNotes('', topNotes, heartNotes, baseNotes);
    const longevity =
      typeof item?.longevity === 'string' && item.longevity.trim()
        ? item.longevity.trim()
        : '24 ساعة';
    const sillage =
      typeof item?.sillage === 'string' && item.sillage.trim()
        ? item.sillage.trim()
        : 'فوحان ممتاز';
    const description =
      typeof item?.description === 'string' && item.description.trim()
        ? item.description.trim()
        : 'منتج أصلي من وكالة بلوكرانا بضمان الثبات والفوحان.';
    const includesFreeTester =
      typeof item?.includesFreeTester === 'boolean'
        ? item.includesFreeTester
        : isQualifyingPerfumeCategory(category);
    const inStock =
      typeof item?.inStock === 'boolean' ? item.inStock : true;

    if (!code || !name || !Number.isFinite(priceIqd) || priceIqd <= 0) {
      res.status(400).json({
        error: 'يرجى التأكد من إدخال رقم العطر، اسم العطر، والسعر بشكل صحيح.',
      });
      return;
    }

    const sanitizedImg = sanitizeImageUrl(item?.imageUrl, category);
    const hasCustomImage =
      typeof item?.hasCustomImage === 'boolean'
        ? item.hasCustomImage
        : sanitizedImg !== DEFAULT_IMAGES.blaugrana;

    const product: Product = {
      id: `${category.slice(0, 2)}-${crypto.randomUUID().slice(0, 8)}`,
      code,
      name,
      brand,
      category,
      priceIqd,
      size,
      ...(sizePrices ? { sizePrices } : {}),
      notes,
      ...(topNotes ? { topNotes } : {}),
      ...(heartNotes ? { heartNotes } : {}),
      ...(baseNotes ? { baseNotes } : {}),
      longevity,
      sillage,
      description,
      imageUrl: sanitizedImg,
      hasCustomImage,
      includesFreeTester,
      inStock,
    };
    createdProducts.push(product);
  }

  db.products = [...createdProducts, ...db.products].sort(compareProductsByCode);
  saveDatabase(db);
  res.status(201).json({ products: createdProducts });
});

// Admin Bulk Update Multiple Products (Images / Prices / Stock at once)
app.put('/api/admin/products/bulk-update', requireAdmin, (req, res) => {
  const updates = Array.isArray(req.body?.updates) ? req.body.updates : [];
  if (updates.length === 0) {
    res.status(400).json({ error: 'لا توجد تعديلات لإرسالها.' });
    return;
  }

  const db = loadDatabase();
  let updatedCount = 0;

  for (const patch of updates as Array<Partial<Product> & { id?: unknown }>) {
    if (typeof patch?.id !== 'string' || !patch.id) continue;
    const product = db.products.find((p) => p.id === patch.id);
    if (!product) continue;

    let changed = false;

    if (typeof patch.imageUrl === 'string') {
      const nextImg = sanitizeImageUrl(patch.imageUrl, product.category);
      product.imageUrl = nextImg;
      product.hasCustomImage =
        typeof patch.hasCustomImage === 'boolean' ? patch.hasCustomImage : true;
      changed = true;
    }

    if (
      typeof patch.priceIqd === 'number' &&
      Number.isFinite(patch.priceIqd) &&
      patch.priceIqd >= 500
    ) {
      product.priceIqd = Math.round(patch.priceIqd);
      changed = true;
    }

    if (patch.sizePrices && typeof patch.sizePrices === 'object') {
      const cleaned: Record<string, number> = {};
      for (const [sz, pr] of Object.entries(patch.sizePrices)) {
        const num = Math.round(Number(pr));
        if (sz.trim() && Number.isFinite(num) && num >= 500) {
          cleaned[sz.trim()] = num;
        }
      }
      if (Object.keys(cleaned).length > 0) {
        product.sizePrices = cleaned;
        if (typeof cleaned['100 مل'] === 'number') {
          product.priceIqd = cleaned['100 مل'];
        }
        changed = true;
      }
    }

    if (typeof patch.inStock === 'boolean') {
      product.inStock = patch.inStock;
      changed = true;
    }

    if (typeof patch.name === 'string' && patch.name.trim()) {
      product.name = patch.name.trim();
      changed = true;
    }

    if (typeof patch.code === 'string' && patch.code.trim()) {
      product.code = patch.code.trim();
      changed = true;
    }

    if (typeof patch.notes === 'string' && patch.notes.trim()) {
      product.notes = patch.notes.trim();
      changed = true;
    }

    if (changed) {
      updatedCount += 1;
    }
  }

  db.products.sort(compareProductsByCode);
  saveDatabase(db);
  res.json({ updatedCount, products: db.products });
});

function reconcileDbSyncPayload(
  db: DatabaseState,
  payload: {
    addedProducts?: unknown;
    updatedProducts?: unknown;
    deletedIds?: unknown;
    promoCodes?: unknown;
    deletedPromoIds?: unknown;
    socialLinks?: unknown;
  }
): number {
  const addedProducts = Array.isArray(payload.addedProducts)
    ? (payload.addedProducts as Product[])
    : [];
  const updatedProducts = Array.isArray(payload.updatedProducts)
    ? (payload.updatedProducts as Product[])
    : [];
  const deletedIds = new Set<string>(
    Array.isArray(payload.deletedIds)
      ? payload.deletedIds.filter((id: unknown): id is string => typeof id === 'string')
      : []
  );
  const incomingPromos = Array.isArray(payload.promoCodes)
    ? (payload.promoCodes as PromoCode[])
    : [];
  const deletedPromoIds = new Set<string>(
    Array.isArray(payload.deletedPromoIds)
      ? payload.deletedPromoIds.filter((id: unknown): id is string => typeof id === 'string')
      : []
  );
  const incomingSocials = Array.isArray(payload.socialLinks)
    ? (payload.socialLinks as SocialLink[])
    : [];

  let syncedCount = 0;

  if (deletedIds.size > 0) {
    const beforeLen = db.products.length;
    db.products = db.products.filter((p) => !deletedIds.has(p.id));
    if (db.products.length !== beforeLen) {
      syncedCount += beforeLen - db.products.length;
    }
    const existingDeleted = new Set(db.deletedSeedIds ?? []);
    for (const id of deletedIds) {
      if (!existingDeleted.has(id)) {
        existingDeleted.add(id);
        syncedCount += 1;
      }
    }
    db.deletedSeedIds = Array.from(existingDeleted);
  }

  for (const raw of addedProducts) {
    if (!raw || typeof raw.id !== 'string' || deletedIds.has(raw.id)) continue;
    if (db.products.some((p) => p.id === raw.id)) continue;
    const category: ProductCategory = VALID_CATEGORIES.has(raw.category)
      ? raw.category
      : 'blaugrana';
    const priceIqd =
      typeof raw.priceIqd === 'number' && Number.isFinite(raw.priceIqd) && raw.priceIqd >= 500
        ? Math.round(raw.priceIqd)
        : 30000;
    const product: Product = {
      id: raw.id,
      code: typeof raw.code === 'string' && raw.code.trim() ? raw.code.trim() : 'M99',
      name: typeof raw.name === 'string' && raw.name.trim() ? raw.name.trim() : 'عطر بلوكرانا',
      brand: typeof raw.brand === 'string' && raw.brand.trim() ? raw.brand.trim() : 'بلوكرانا',
      category,
      priceIqd,
      size: typeof raw.size === 'string' && raw.size.trim() ? raw.size.trim() : '100 مل',
      ...(raw.sizePrices ? { sizePrices: raw.sizePrices } : {}),
      notes: typeof raw.notes === 'string' && raw.notes.trim() ? raw.notes.trim() : 'تركيبة فاخرة',
      ...(raw.topNotes ? { topNotes: raw.topNotes } : {}),
      ...(raw.heartNotes ? { heartNotes: raw.heartNotes } : {}),
      ...(raw.baseNotes ? { baseNotes: raw.baseNotes } : {}),
      longevity: typeof raw.longevity === 'string' && raw.longevity.trim() ? raw.longevity.trim() : '24 ساعة',
      sillage: typeof raw.sillage === 'string' && raw.sillage.trim() ? raw.sillage.trim() : 'فوحان ممتاز',
      description:
        typeof raw.description === 'string' && raw.description.trim()
          ? raw.description.trim()
          : 'منتج أصلي من وكالة بلوكرانا بضمان الثبات والفوحان.',
      imageUrl: sanitizeImageUrl(raw.imageUrl, category),
      hasCustomImage: typeof raw.hasCustomImage === 'boolean' ? raw.hasCustomImage : true,
      includesFreeTester:
        typeof raw.includesFreeTester === 'boolean'
          ? raw.includesFreeTester
          : isQualifyingPerfumeCategory(category),
      inStock: typeof raw.inStock === 'boolean' ? raw.inStock : true,
    };
    db.products.unshift(product);
    syncedCount += 1;
  }

  for (const raw of updatedProducts) {
    if (!raw || typeof raw.id !== 'string' || deletedIds.has(raw.id)) continue;
    const idx = db.products.findIndex((p) => p.id === raw.id);
    if (idx === -1) continue;
    const existing = db.products[idx];
    const category: ProductCategory = VALID_CATEGORIES.has(raw.category)
      ? raw.category
      : existing.category;
    const nextImg = sanitizeImageUrl(raw.imageUrl, category);
    const merged: Product = {
      ...existing,
      ...raw,
      category,
      imageUrl: nextImg,
      hasCustomImage: typeof raw.hasCustomImage === 'boolean' ? raw.hasCustomImage : true,
    };
    if (JSON.stringify(merged) !== JSON.stringify(existing)) {
      db.products[idx] = merged;
      syncedCount += 1;
    }
  }

  if (deletedPromoIds.size > 0) {
    const beforePromos = db.promoCodes.length;
    db.promoCodes = db.promoCodes.filter((p) => !deletedPromoIds.has(p.id));
    if (db.promoCodes.length !== beforePromos) {
      syncedCount += beforePromos - db.promoCodes.length;
    }
  }

  for (const rawPromo of incomingPromos) {
    if (!rawPromo || typeof rawPromo.id !== 'string' || deletedPromoIds.has(rawPromo.id)) {
      continue;
    }
    const normalizedCode =
      typeof rawPromo.code === 'string' ? normalizePromoCode(rawPromo.code) : '';
    const ownerName =
      typeof rawPromo.ownerName === 'string' ? rawPromo.ownerName.trim() : '';
    const discountType: PromoDiscountType =
      rawPromo.discountType === 'fixed' ? 'fixed' : 'percent';
    const discountValue = Math.round(Number(rawPromo.discountValue ?? 0));
    if (!normalizedCode || ownerName.length < 2 || !Number.isFinite(discountValue) || discountValue <= 0) {
      continue;
    }
    const exists = db.promoCodes.some(
      (p) => p.id === rawPromo.id || normalizePromoCode(p.code) === normalizedCode
    );
    if (exists) continue;
    db.promoCodes.unshift({
      id: rawPromo.id,
      code: normalizedCode,
      ownerName,
      discountType,
      discountValue,
      durationDays:
        typeof rawPromo.durationDays === 'number' && Number.isFinite(rawPromo.durationDays)
          ? rawPromo.durationDays
          : null,
      expiresAt:
        typeof rawPromo.expiresAt === 'string' && rawPromo.expiresAt.trim()
          ? rawPromo.expiresAt.trim()
          : null,
      active: typeof rawPromo.active === 'boolean' ? rawPromo.active : true,
      timesUsed: typeof rawPromo.timesUsed === 'number' ? rawPromo.timesUsed : 0,
      createdAt:
        typeof rawPromo.createdAt === 'string' && rawPromo.createdAt
          ? rawPromo.createdAt
          : new Date().toISOString(),
    });
    syncedCount += 1;
  }

  for (const rawSoc of incomingSocials) {
    if (!rawSoc || typeof rawSoc.id !== 'string' || typeof rawSoc.url !== 'string') continue;
    const safeUrl = sanitizeHref(rawSoc.url);
    if (safeUrl === '#') continue;
    if (db.socialLinks.some((s) => s.id === rawSoc.id || s.url === safeUrl)) continue;
    db.socialLinks.push({
      id: rawSoc.id,
      platform: String(rawSoc.platform ?? '').trim() || 'رابط',
      label: String(rawSoc.label ?? rawSoc.platform ?? '').trim() || 'رابط',
      handle: String(rawSoc.handle ?? '').trim() || safeUrl,
      url: safeUrl,
    });
    syncedCount += 1;
  }

  db.products.sort(compareProductsByCode);
  return syncedCount;
}

// Admin Sync Catalog (Reconcile client-persisted additions/edits/deletions across ephemeral server restarts)
app.post('/api/admin/sync-catalog', requireAdmin, (req, res) => {
  const db = loadDatabase();
  const syncedCount = reconcileDbSyncPayload(db, req.body ?? {});
  if (syncedCount > 0) {
    saveDatabase(db);
  }
  res.json({
    syncedCount,
    products: db.products,
    promoCodes: db.promoCodes,
    socialLinks: db.socialLinks,
  });
});

// Admin Global Save All Site Changes
app.post('/api/admin/save-all', requireAdmin, (req, res) => {
  const db = loadDatabase();
  const syncedCount = reconcileDbSyncPayload(db, req.body ?? {});
  saveDatabase(db);
  res.json({
    ok: true,
    syncedCount,
    products: db.products,
    promoCodes: db.promoCodes,
    socialLinks: db.socialLinks,
    telegramStatus: getTelegramPublicStatus(db),
  });
});

// Admin Update Product
app.put('/api/admin/products/:id', requireAdmin, (req, res) => {
  const db = loadDatabase();
  const product = db.products.find((p) => p.id === req.params.id);
  if (!product) {
    res.status(404).json({ error: 'المنتج غير موجود.' });
    return;
  }

  const body = req.body as Partial<Product>;
  if (typeof body.code === 'string' && body.code.trim()) {
    product.code = body.code.trim();
  }
  if (typeof body.name === 'string' && body.name.trim()) {
    product.name = body.name.trim();
  }
  if (typeof body.brand === 'string' && body.brand.trim()) {
    product.brand = body.brand.trim();
  }
  if (body.category && VALID_CATEGORIES.has(body.category)) {
    product.category = body.category;
  }
  if (typeof body.priceIqd === 'number' && Number.isFinite(body.priceIqd) && body.priceIqd >= 500) {
    product.priceIqd = Math.round(body.priceIqd);
  }
  if (body.sizePrices && typeof body.sizePrices === 'object') {
    const cleaned: Record<string, number> = {};
    for (const [sz, pr] of Object.entries(body.sizePrices)) {
      const num = Math.round(Number(pr));
      if (sz.trim() && Number.isFinite(num) && num >= 500) {
        cleaned[sz.trim()] = num;
      }
    }
    if (Object.keys(cleaned).length > 0) {
      product.sizePrices = cleaned;
      if (typeof cleaned['100 مل'] === 'number') {
        product.priceIqd = cleaned['100 مل'];
      }
    }
  }
  if (typeof body.size === 'string' && body.size.trim()) {
    product.size = body.size.trim();
  }
  if (typeof body.topNotes === 'string') {
    product.topNotes = body.topNotes.trim() || undefined;
  }
  if (typeof body.heartNotes === 'string') {
    product.heartNotes = body.heartNotes.trim() || undefined;
  }
  if (typeof body.baseNotes === 'string') {
    product.baseNotes = body.baseNotes.trim() || undefined;
  }
  if (typeof body.notes === 'string' && body.notes.trim()) {
    product.notes = body.notes.trim();
  } else if (
    typeof body.topNotes === 'string' ||
    typeof body.heartNotes === 'string' ||
    typeof body.baseNotes === 'string'
  ) {
    product.notes = buildCombinedNotes(
      product.notes,
      product.topNotes,
      product.heartNotes,
      product.baseNotes
    );
  }
  if (typeof body.longevity === 'string') {
    product.longevity = body.longevity.trim();
  }
  if (typeof body.sillage === 'string') {
    product.sillage = body.sillage.trim();
  }
  if (typeof body.description === 'string') {
    product.description = body.description.trim();
  }
  if (typeof body.imageUrl === 'string') {
    product.imageUrl = sanitizeImageUrl(body.imageUrl, product.category);
    product.hasCustomImage =
      typeof body.hasCustomImage === 'boolean'
        ? body.hasCustomImage
        : product.imageUrl !== DEFAULT_IMAGES.blaugrana;
  } else if (typeof body.hasCustomImage === 'boolean') {
    product.hasCustomImage = body.hasCustomImage;
  }
  if (typeof body.includesFreeTester === 'boolean') {
    product.includesFreeTester = body.includesFreeTester;
  }
  if (typeof body.inStock === 'boolean') {
    product.inStock = body.inStock;
  }

  db.products.sort(compareProductsByCode);
  saveDatabase(db);
  res.json({ product });
});

// Admin Promo Codes CRUD
app.post('/api/admin/promo-codes', requireAdmin, (req, res) => {
  const code =
    typeof req.body?.code === 'string' ? normalizePromoCode(req.body.code) : '';
  const ownerName =
    typeof req.body?.ownerName === 'string' ? req.body.ownerName.trim() : '';
  const discountType: PromoDiscountType =
    req.body?.discountType === 'fixed' ? 'fixed' : 'percent';
  const discountValue = Math.round(Number(req.body?.discountValue ?? 0));

  if (code.length < 2 || code.length > 24) {
    res.status(400).json({
      error: 'يجب أن يتكون كود البروموكود من 2 إلى 24 حرفاً أو رقماً.',
    });
    return;
  }
  if (ownerName.length < 2) {
    res.status(400).json({
      error: 'يرجى كتابة اسم الشخص صاحب البروموكود.',
    });
    return;
  }
  if (
    discountType === 'percent' &&
    (!Number.isFinite(discountValue) || discountValue < 1 || discountValue > 100)
  ) {
    res.status(400).json({
      error: 'نسبة الخصم يجب أن تكون بين 1% و 100%.',
    });
    return;
  }
  if (
    discountType === 'fixed' &&
    (!Number.isFinite(discountValue) || discountValue < 500)
  ) {
    res.status(400).json({
      error: 'مبلغ الخصم الثابت يجب أن يكون 500 د.ع فأكثر.',
    });
    return;
  }

  const rawDuration = req.body?.durationDays;
  let durationDays: number | null = null;
  let expiresAt: string | null = null;
  if (rawDuration !== undefined && rawDuration !== null && rawDuration !== '') {
    const parsedDays = Math.round(Number(rawDuration));
    if (!Number.isFinite(parsedDays) || parsedDays < 0 || parsedDays > 3650) {
      res.status(400).json({
        error: 'مدة الصلاحية بالأيام يجب أن تكون بين 0 (دائم) و 3650 يوم.',
      });
      return;
    }
    if (parsedDays > 0) {
      durationDays = parsedDays;
      expiresAt = new Date(Date.now() + parsedDays * 86_400_000).toISOString();
    }
  }

  const db = loadDatabase();
  if (db.promoCodes.some((p) => normalizePromoCode(p.code) === code)) {
    res.status(409).json({
      error: `الكود «${code}» موجود مسبقاً، يرجى اختيار كود مختلف.`,
    });
    return;
  }

  const promoCode: PromoCode = {
    id: `pr-${crypto.randomUUID().slice(0, 8)}`,
    code,
    ownerName,
    discountType,
    discountValue,
    durationDays,
    expiresAt,
    active: true,
    timesUsed: 0,
    createdAt: new Date().toISOString(),
  };

  db.promoCodes.unshift(promoCode);
  saveDatabase(db);
  res.status(201).json({ promoCode });
});

app.patch('/api/admin/promo-codes/:id', requireAdmin, (req, res) => {
  const db = loadDatabase();
  const promo = db.promoCodes.find((p) => p.id === req.params.id);
  if (!promo) {
    res.status(404).json({ error: 'كود الخصم غير موجود.' });
    return;
  }
  if (typeof req.body?.active === 'boolean') {
    promo.active = req.body.active;
  }
  if (typeof req.body?.ownerName === 'string' && req.body.ownerName.trim()) {
    promo.ownerName = req.body.ownerName.trim();
  }
  if (req.body?.durationDays !== undefined) {
    const parsedDays = Math.round(Number(req.body.durationDays));
    if (
      req.body.durationDays === null ||
      req.body.durationDays === '' ||
      parsedDays === 0
    ) {
      promo.durationDays = null;
      promo.expiresAt = null;
    } else if (Number.isFinite(parsedDays) && parsedDays > 0 && parsedDays <= 3650) {
      promo.durationDays = parsedDays;
      promo.expiresAt = new Date(Date.now() + parsedDays * 86_400_000).toISOString();
    } else {
      res.status(400).json({
        error: 'مدة الصلاحية بالأيام يجب أن تكون بين 0 (دائم) و 3650 يوم.',
      });
      return;
    }
  }
  saveDatabase(db);
  res.json({ promoCode: promo });
});

app.delete('/api/admin/promo-codes/:id', requireAdmin, (req, res) => {
  const db = loadDatabase();
  const before = db.promoCodes.length;
  db.promoCodes = db.promoCodes.filter((p) => p.id !== req.params.id);
  if (db.promoCodes.length === before) {
    res.status(404).json({ error: 'كود الخصم غير موجود.' });
    return;
  }
  saveDatabase(db);
  res.json({ ok: true });
});

// Admin Delete Product
app.delete('/api/admin/products/:id', requireAdmin, (req, res) => {
  const db = loadDatabase();
  const before = db.products.length;
  const targetId = String(req.params.id ?? '');
  db.products = db.products.filter((p) => p.id !== targetId);
  if (db.products.length === before) {
    res.status(404).json({ error: 'المنتج غير موجود.' });
    return;
  }
  if (!db.deletedSeedIds) {
    db.deletedSeedIds = [];
  }
  if (!db.deletedSeedIds.includes(targetId)) {
    db.deletedSeedIds.push(targetId);
  }
  saveDatabase(db);
  res.json({ ok: true });
});

// Admin Social Links CRUD
app.post('/api/admin/social-links', requireAdmin, (req, res) => {
  const platform =
    typeof req.body?.platform === 'string' ? req.body.platform.trim() : '';
  const label =
    typeof req.body?.label === 'string' ? req.body.label.trim() : platform;
  const handle =
    typeof req.body?.handle === 'string' ? req.body.handle.trim() : '';
  const rawUrl = typeof req.body?.url === 'string' ? req.body.url.trim() : '';
  const url = sanitizeHref(rawUrl);

  if (!platform || !handle || url === '#') {
    res.status(400).json({
      error: 'يرجى إدخال اسم المنصة، المعرّف/الرقم، ورابط صحيح يبدأ بـ https://',
    });
    return;
  }

  const db = loadDatabase();
  const link: SocialLink = {
    id: `soc-${crypto.randomUUID().slice(0, 8)}`,
    platform,
    label: label || platform,
    handle,
    url,
  };
  db.socialLinks.push(link);
  saveDatabase(db);
  res.status(201).json({ socialLink: link });
});

app.put('/api/admin/social-links/:id', requireAdmin, (req, res) => {
  const db = loadDatabase();
  const link = db.socialLinks.find((s) => s.id === req.params.id);
  if (!link) {
    res.status(404).json({ error: 'رابط التواصل غير موجود.' });
    return;
  }
  if (typeof req.body?.platform === 'string' && req.body.platform.trim()) {
    link.platform = req.body.platform.trim();
  }
  if (typeof req.body?.label === 'string' && req.body.label.trim()) {
    link.label = req.body.label.trim();
  }
  if (typeof req.body?.handle === 'string' && req.body.handle.trim()) {
    link.handle = req.body.handle.trim();
  }
  if (typeof req.body?.url === 'string') {
    const safe = sanitizeHref(req.body.url);
    if (safe === '#') {
      res.status(400).json({ error: 'الرابط غير صالح.' });
      return;
    }
    link.url = safe;
  }
  saveDatabase(db);
  res.json({ socialLink: link });
});

app.delete('/api/admin/social-links/:id', requireAdmin, (req, res) => {
  const db = loadDatabase();
  const before = db.socialLinks.length;
  db.socialLinks = db.socialLinks.filter((s) => s.id !== req.params.id);
  if (db.socialLinks.length === before) {
    res.status(404).json({ error: 'رابط التواصل غير موجود.' });
    return;
  }
  saveDatabase(db);
  res.json({ ok: true });
});

async function startServer() {
  const distDir = path.resolve(process.cwd(), 'dist');
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(distDir);

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Blaugrana Perfumes server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
